import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;

class Person{//create person class for arraylist to add
	public String name;
	public int age;
	Person(String name, int age){
		this.name = name;
		this.age = age;
	}
}
public class HashVSNoHash {
	public static void main(String[] args) throws IOException {
		HashMap<String, Integer> hm = new HashMap<String, Integer>();
		for(int i = 0; i < 1000000; i++){
			hm.put("YYX"+ Integer.toString(i), i%100);//ages are from 0 to 99
		}
		Hashtable<String, Integer> ht = new Hashtable<String, Integer>();
		for(int i = 0; i < 1000000; i++){
			ht.put("YYX"+ Integer.toString(i), i%100);
		}
		ArrayList<Person> arr = new ArrayList<Person>();
		for(int i = 0; i < 1000000; i++){
			Person temp = new Person("YYX" + Integer.toString(i),i%100);
			arr.add(temp);
		}
		System.out.println("PLEASE INPUT THE NAME OF A PERSON(FROM YYX0 TO YYX1000000)");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String word = br.readLine().toString();//Input the name you want to look up
		
		System.out.println("Using HashMap:");
		long start1 = System.nanoTime();//with hashmap
		System.out.println("The age of the person is " + hm.get(word));
		long end1 = System.nanoTime();
		System.out.println("It costs " + (end1 - start1) + " ns");
		
		System.out.println("Using HashTable:");
		long start2 = System.nanoTime();//with hashtable
		System.out.println("The age of the person is " + hm.get(word));
		long end2 = System.nanoTime();
		System.out.println("It costs " + (end2 - start2) + " ns");
		
		System.out.println("Using ArrayList with liner algorithm:");
		long start3 = System.nanoTime();//with arraylist and liner algorithm to find
		for (int i = 0; i < arr.size(); i++){//the algorithm complexity is n
			if(arr.get(i).name.equals(word)){//can not sort because sort it you need nlogn at least
				System.out.println("The age of the person is " + arr.get(i).age);
				break;
			}
		}
		long end3 = System.nanoTime();
		System.out.println("It costs " + (end3 - start3) + " ns");
	}
	
}
