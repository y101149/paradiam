import java.util.Stack;

public class QuickSortWithNonRecursion {//use stack to remember the postition of low and high,
	public static void Qsort(double a[], int low, int high){//in this way, we do not need to use recursion
		Stack<Integer> stack = new Stack<Integer>();
		int i, j;
		if (low > high)
			return;
		stack.push(high);
		stack.push(low);
		while(!stack.empty()){
			i = stack.pop();
			j = stack.pop();
			if (i < j){
				int k = findIndex(a,i,j);
				if(k > i){
					stack.push(k - 1);
					stack.push(i);
				}
				if(k < j){
					stack.push(j);
					stack.push(k + 1);
				}
			}
		}
		
	}
	public static int findIndex(double a[], int low, int high){
		if (low > high){
			return -1;
		}
		int first = low, last = high;
		double key = a[first];
		while (first < last){
			while (first < last && a[last] >= key){
				--last;
			}
			a[first] = a[last];

			while (first < last && a[first] <= key){
				++first;
			}
			a[last] = a[first];

		}
		a[first] = key;

		return first;
	}
	public static void main(String[] args) {
		double array[] = {11.1,88.8,76.5,2,3.33,56.97,100.5,99.9,4.43,22.22,-4.4};
		Qsort(array, 0, array.length-1);
		for (int i = 0; i < array.length; i++){
			System.out.println(array[i]);
		}
	}

}
