public class QuickSortWithRecursion {
	public static void Qsort(double a[], int low, int high){
		if (low >= high){
			return;
		}
		int first = low, last = high;
		double key = a[first];
		while (first < last){
			while (first < last && a[last] >= key){
				--last;
			}
			a[first] = a[last];
			while (first < last && a[first] <= key){
				++first;
			}
			a[last] = a[first];
		}
		a[first] = key;
		Qsort(a, low, first-1);
		Qsort(a, first+1, high);
	}
	
	public static void main(String[] args) {
		double array[] = {11.1,88.8,76.5,2,3.33,56.97,100.5,99.9,4.43,22.22,-4.4};
		Qsort(array,0, array.length-1);
		for(int i = 0; i < array.length; i++){
			System.out.println(array[i]);
		}
	}
	
	

}
