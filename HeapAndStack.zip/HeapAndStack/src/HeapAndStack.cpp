//============================================================================
// Name        : HeapAndStack.cpp
// Author      : Yyx
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int size = 1000;//define the size of the array,both have 1000 integer

//void fillValueInArray(int array[], int size){
//	for(int i = 0; i < size; i++){
//		array[i] = rand();
//	}
//}

void stackCreate (int size){//create an array on stack, maybe fill some random value
	int stackArray[size];
//	fillValueInArray(stackArray,size);
}

void heapCreate (int size){//create an array on heap, maybe fill some random value
	int *heapArray = new int[size];
//	fillValueInArray(heapArray,size);
}

int main() {
	clock_t start1 = clock();//remember the beginning time
	for (int i = 0; i < 100000; i++){//call it 100000 times
		stackCreate(size);//
	}
	double time1 = (double)(clock() - start1)/CLOCKS_PER_SEC;//calculate the processing time
	cout << time1;//output the time to crate an array on stack
	cout << "\n";//out put a "\n"
	clock_t start2 = clock();
	for (int i = 0; i < 100000; i++){
		heapCreate(size);
	}
	double time2 = (double)(clock()-start2)/CLOCKS_PER_SEC;//calcllate the processing time
	cout << time2;//out put the time to create an array on heap
	return 0;
}



