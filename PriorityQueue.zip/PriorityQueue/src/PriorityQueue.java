
public class PriorityQueue {
	
	private queueElement[] queue;
	private int index;
	
	public queueElement[] getQueue() {
		return queue;
	}
	public void setQueue(queueElement[] queue) {
		this.queue = queue;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public PriorityQueue(){
		queue = new queueElement[200];
		index = 0;
	}
	public void enqueue(String str, int pri){
		queueElement element = new queueElement();
		element.setData(str);
		element.setPriority(pri);
		queue[index] = element;
		index++;
	}
	public String dequeue(){
		if (index == 0){
			return null;
		}
		
		int maxindex = 0;
		for (int i = 0; i < index; i++){
			if (queue[i].getPriority() > queue[maxindex].getPriority()){
				maxindex = i;
			}
		}
		queueElement ret = queue[maxindex];
		queue[maxindex] = queue[--index];//move the last element to the position of highest priority position(to be deleted)
		return ret.getData();
	}
	
	public boolean isEmpty(){
		return index == 0;
	}
	
	public void empty(){
		if (index == 0){
			System.out.println("The queue is already empty");
			return;
		}
		else{
			int originalLen = index + 1;
			index = 0;
			System.out.println("Queue is empty now, the original lenth is " + originalLen);
		}
	}
	

	
}
