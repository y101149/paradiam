
public class queueElement{
	private int priority;
	private String data;

	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public queueElement() {
		priority = 0;
		data = "";
		// TODO Auto-generated constructor stub
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((data == null) ? 0 : data.hashCode());
		result = prime * result + priority;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (obj == null){
			return false;
		}
		if (obj == this){
			return true;
		}
		if(getClass() != obj.getClass()){
			return false;
		}
		queueElement qe = (queueElement) obj;
		return ((this.getData() == qe.getData()) && (this.getPriority() == qe.getPriority()));
	}
	
	@Override
	public queueElement clone(){
		queueElement ele = new queueElement();
		ele.setData(this.data);
		ele.setPriority(this.priority);
		return ele;
	}
	@Override
	public String toString(){
		String retStr = "";
		retStr += "myData is "+ this.getData();
		retStr += " and myPriority is "+ this.getPriority();
		return retStr;
		
	}
	
	
}