import java.util.HashSet;


public class TestAll {
	public static void main(String[] args) {
		//first we test the queueElement class
		//we will test the override hashcode, tostring, equals and clone method
		
		/*
		 * Test the override equal method. if we don't override, it will return false
		 * because they are different object even though their contents are the same;
		 */
		queueElement ele1 = new queueElement();
		queueElement ele2 = new queueElement();
		queueElement ele3 = new queueElement();

		ele1.setData("yyx");
		ele1.setPriority(1);
		ele2.setData("yyx");
		ele2.setPriority(1);
		ele3.setData("NeverMore");
		ele3.setPriority(666);
		System.out.println("----------------------------------------------");
		System.out.println(ele1.equals(ele2));
		System.out.println(ele1.equals(ele3));

		
		/*
		 * Test the override hashcode method
		 * in the example, ele1 and ele2 are the same while ele3 is different
		 * if we don't overwrite hashcode method, the hashset should contain 3 object
		 * since we overwrite hashcode, the hashset only contains 2 element. because their
		 * hash codes are the same
		 */
		System.out.println("----------------------------------------------");
		System.out.println(ele1.hashCode());
		System.out.println(ele2.hashCode());
		System.out.println(ele3.hashCode());
		HashSet<queueElement> hashset = new HashSet<queueElement>();
		hashset.add(ele1);
		hashset.add(ele2);
		hashset.add(ele3);
		System.out.println(hashset.size());//it should return 2 because we overwrite the hashcode

		/*
		 * Test the override clone function
		 * and the toString function
		 * Since we overwrite the clone and toString function
		 * we can see that we clone the ele3 to ele4 and successfully
		 * output our wanted string(the format we defined in the toString method)
		 */
		System.out.println("----------------------------------------------");
		queueElement ele4 = new queueElement();
		ele4 = ele3.clone();
		System.out.println(ele4.toString());
		
		//Then we test our PriorityQueue Class
		//We will test enque, deque, empty method
		PriorityQueue myqueue = new PriorityQueue();
		myqueue.enqueue("yyx1", 4);
		myqueue.enqueue("yyx2", 19);
		myqueue.enqueue("yyx4", 2);
		myqueue.enqueue("yyx3", 41);
		myqueue.enqueue("yyx5", 8);
		myqueue.enqueue("yyx7", 88);
		myqueue.enqueue("yyx9", 42);

		System.out.println("----------------------------------------------");
		for (int i = 0; i < myqueue.getIndex(); i++){
			System.out.println(myqueue.getQueue()[i]);
		}
		System.out.println("----------------------------------------------");
		System.out.println(myqueue.dequeue());
		System.out.println("----------------------------------------------");
		myqueue.empty();
		for (int i = 0; i < myqueue.getIndex(); i++){
			System.out.println(myqueue.getQueue()[i]);
		}

		
		

	}
}
